Unzip and replace lib/main.dart with the full project files after configuring Firebase.
