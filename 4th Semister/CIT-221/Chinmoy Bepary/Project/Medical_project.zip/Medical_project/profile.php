<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$name = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>User Profile</title>
    <link rel="stylesheet" href="profile.css" />
</head>
<body>
    <div class="profile-container">
        <h2>Welcome, <?php echo htmlspecialchars($name); ?>!</h2>
        <ul class="nav-links">
            <li><a href="admit_patient.php">Admit Patient</a></li>
            <li><a href="serial_list.php">View Serial List</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
        <a href="index.php" class="back-btn">← Back to Homepage</a>
    </div>
</body>
</html>
