<?php
session_start();
require 'db_connect.php'; // Update with your actual DB file path

// Admin authentication check
if (!isset($_SESSION['admin_name'])) {
    header("Location: admin_login.php");
    exit();
}

// Fetch all serials
$sql = "SELECT a.id, a.serial_no, a.patient_name, a.admit_date, a.phone, d.name AS doctor_name
        FROM admissions a
        JOIN doctors d ON a.doctor_id = d.id
        ORDER BY a.admit_date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Serials</title>
    <link rel="stylesheet" href="admin_dashboard.css">
    <style>
        .serial-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
        }

        .serial-table th, .serial-table td {
            border: 1px solid #ccc;
            padding: 12px;
            text-align: center;
        }

        .serial-table th {
            background-color: #2c3e50;
            color: white;
        }

        .serial-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .action-btn {
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            color: white;
            font-weight: bold;
        }

        .edit-btn {
            background-color: #27ae60;
        }

        .delete-btn {
            background-color: #e74c3c;
        }

        .delete-btn:hover {
            background-color: #c0392b;
        }

        .edit-btn:hover {
            background-color: #219150;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #2980b9;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        h2 {
            text-align: center;
            margin-top: 30px;
            color: #2c3e50;
        }
    </style>
</head>
<body>
    <header>
        <h1>Manage Serials</h1>
        <a href="admin_dashboard.php" class="btn logout-btn">← Back to Dashboard</a>
    </header>

    <main>
        <h2>All Serial Records</h2>
        <table class="serial-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Serial No</th>
                    <th>Doctor</th>
                    <th>Patient Name</th>
                    <th>Phone</th>
                    <th>Admit Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['id'] ?></td>
                            <td>#<?= $row['serial_no'] ?></td>
                            <td><?= htmlspecialchars($row['doctor_name']) ?></td>
                            <td><?= htmlspecialchars($row['patient_name']) ?></td>
                            <td><?= htmlspecialchars($row['phone']) ?></td>
                            <td><?= $row['admit_date'] ?></td>
                            <td>
                                <a href="edit_serial.php?id=<?= $row['id'] ?>" class="action-btn edit-btn">Edit</a>
                                <a href="delete_serial.php?id=<?= $row['id'] ?>" class="action-btn delete-btn" onclick="return confirm('Are you sure you want to delete this serial?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="7">No serial records found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </main>
</body>
</html>
