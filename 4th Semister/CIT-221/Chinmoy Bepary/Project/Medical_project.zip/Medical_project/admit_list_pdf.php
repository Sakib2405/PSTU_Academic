<?php
require('fpdf/fpdf.php');
include 'db_connect.php';

// Create a new PDF document
$pdf = new FPDF('L', 'mm', 'A4');
$pdf->AddPage();

// Set font
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'Admit Patient List', 0, 1, 'C');
$pdf->Ln(5);

// Table headers
$pdf->SetFont('Arial', 'B', 11);
$pdf->SetFillColor(200, 220, 255);
$pdf->Cell(20, 10, 'Serial', 1, 0, 'C', true);
$pdf->Cell(45, 10, 'Patient Name', 1, 0, 'C', true);
$pdf->Cell(15, 10, 'Age', 1, 0, 'C', true);
$pdf->Cell(20, 10, 'Gender', 1, 0, 'C', true);
$pdf->Cell(35, 10, 'Phone', 1, 0, 'C', true);
$pdf->Cell(50, 10, 'Doctor', 1, 0, 'C', true);
$pdf->Cell(45, 10, 'Specialization', 1, 0, 'C', true);
$pdf->Cell(35, 10, 'Admit Date', 1, 1, 'C', true);

// Fetch data from DB
$sql = "SELECT a.serial_no, a.patient_name, a.patient_age, a.patient_gender, a.phone,
        a.admit_date, d.name AS doctor_name, d.specialization
        FROM admissions a
        JOIN doctors d ON a.doctor_id = d.id
        ORDER BY a.admit_date DESC, a.serial_no ASC";

$result = $conn->query($sql);

// Table content
$pdf->SetFont('Arial', '', 10);
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell(20, 8, $row['serial_no'], 1);
        $pdf->Cell(45, 8, $row['patient_name'], 1);
        $pdf->Cell(15, 8, $row['patient_age'], 1);
        $pdf->Cell(20, 8, $row['patient_gender'], 1);
        $pdf->Cell(35, 8, $row['phone'], 1);
        $pdf->Cell(50, 8, $row['doctor_name'], 1);
        $pdf->Cell(45, 8, $row['specialization'], 1);
        $pdf->Cell(35, 8, $row['admit_date'], 1);
        $pdf->Ln();
    }
} else {
    $pdf->Cell(0, 10, 'No patient data found.', 1, 1, 'C');
}

$conn->close();
$pdf->Output('I', 'admit_patient_list.pdf');
?>
