<?php
session_start();
include 'db_connect.php';

// Admin session check
if (!isset($_SESSION['admin_name'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_users.php");
    exit();
}

// Handle search
$search = isset($_GET['search']) ? trim($_GET['search']) : "";
$sql = "SELECT id, name, email FROM users";
if ($search !== "") {
    $sql .= " WHERE name LIKE ? OR email LIKE ?";
    $stmt = $conn->prepare($sql);
    $searchTerm = "%$search%";
    $stmt->bind_param("ss", $searchTerm, $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
} else {
    $result = $conn->query($sql . " ORDER BY id DESC");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Manage Users - Admin</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #007bff;
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
        }

        header .actions a {
            background: white;
            color: #007bff;
            text-decoration: none;
            padding: 8px 14px;
            border-radius: 5px;
            margin-left: 10px;
            font-weight: bold;
        }

        .container {
            max-width: 1000px;
            margin: 30px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 8px rgba(0,0,0,0.1);
        }

        .search-bar {
            margin-bottom: 15px;
            text-align: right;
        }

        .search-bar input[type="text"] {
            padding: 8px;
            width: 250px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .search-bar button {
            padding: 8px 14px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            margin-left: 5px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table th, table td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        table th {
            background-color: #f4f4f4;
        }

        .delete-btn {
            color: white;
            background-color: #dc3545;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }

        .no-users {
            text-align: center;
            margin-top: 20px;
            color: #666;
        }

        footer {
            text-align: center;
            margin-top: 30px;
            padding: 10px;
            background-color: #f8f8f8;
            color: #666;
        }
    </style>
</head>
<body>

<header>
    <h1>Manage Users</h1>
    <div class="actions">
        <a href="admin_dashboard.php">← Dashboard</a>
        <a href="add_user.php">+ Add User</a>
        <a href="logout.php">Logout</a>
    </div>
</header>

<div class="container">
    <form class="search-bar" method="GET" action="manage_users.php">
        <input type="text" name="search" placeholder="Search by name or email..." value="<?= htmlspecialchars($search) ?>" />
        <button type="submit">Search</button>
    </form>

    <?php if ($result && $result->num_rows > 0): ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($user = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($user['id']) ?></td>
                <td><?= htmlspecialchars($user['name']) ?></td>
                <td><?= htmlspecialchars($user['email']) ?></td>
                <td>
                    <a class="delete-btn" href="manage_users.php?delete_id=<?= $user['id'] ?>" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p class="no-users">No users found.</p>
    <?php endif; ?>
</div>

<footer>
    &copy; <?= date('Y') ?> Medical Project Admin Panel
</footer>

</body>
</html>

<?php
$conn->close();
?>
