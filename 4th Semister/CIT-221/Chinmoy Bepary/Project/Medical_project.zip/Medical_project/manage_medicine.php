<?php
session_start();
include 'db_connect.php';

// Check admin session
if (!isset($_SESSION['admin_name'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $stmt = $conn->prepare("DELETE FROM medicine WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    $stmt->close();

    header("Location: manage_medicine.php");
    exit();
}

// Fetch all medicines
$result = $conn->query("SELECT id, name, manufacturer, expiry_date, quantity FROM medicine ORDER BY id DESC");
if ($result === false) {
    echo "Database error: " . $conn->error;
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Manage Medicine - Admin</title>
    <style>
        /* General Reset */
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0 20px 40px 20px;
            color: #333;
        }
        header {
            padding: 20px 0;
            border-bottom: 2px solid #4CAF50;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        header h1 {
            margin: 0;
            color: #4CAF50;
            font-weight: 700;
        }
        a.btn {
            text-decoration: none;
            padding: 8px 14px;
            border-radius: 5px;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }
        .back-btn {
            background-color: #2196F3;
            color: white;
            margin-right: 10px;
        }
        .back-btn:hover {
            background-color: #0b7dda;
        }
        .logout-btn {
            background-color: #f44336;
            color: white;
        }
        .logout-btn:hover {
            background-color: #d32f2f;
        }

        main {
            margin-top: 20px;
        }
        .add-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 16px;
            display: inline-block;
            margin-bottom: 15px;
            font-weight: 600;
        }
        .add-btn:hover {
            background-color: #45a049;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
            font-weight: 700;
        }
        tr:hover {
            background-color: #f1f1f1;
        }

        .low-stock {
            color: red;
            font-weight: bold;
        }

        .edit-btn, .delete-btn {
            padding: 6px 12px;
            border-radius: 5px;
            color: white;
            font-weight: 600;
            text-decoration: none;
            transition: background-color 0.3s ease;
            display: inline-block;
            margin-right: 5px;
        }
        .edit-btn {
            background-color: #2196F3;
        }
        .edit-btn:hover {
            background-color: #0b7dda;
        }
        .delete-btn {
            background-color: #f44336;
        }
        .delete-btn:hover {
            background-color: #d32f2f;
        }

        footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ccc;
            color: #666;
            font-size: 14px;
        }

        /* Responsive */
        @media (max-width: 600px) {
            table, thead, tbody, th, td, tr {
                display: block;
            }
            th, td {
                padding: 10px;
                text-align: right;
                position: relative;
            }
            th {
                background-color: transparent;
                color: #666;
                font-weight: 600;
                border-bottom: none;
            }
            td {
                border-bottom: 1px solid #ddd;
                padding-left: 50%;
                text-align: left;
            }
            td::before {
                content: attr(data-label);
                position: absolute;
                left: 15px;
                width: 45%;
                padding-left: 15px;
                font-weight: 700;
                text-align: left;
                color: #333;
            }
            .edit-btn, .delete-btn {
                margin: 5px 5px 0 0;
                display: inline-block;
            }
        }
    </style>
</head>
<body>

<header>
    <h1>Manage Medicine</h1>
    <div>
        <a href="admin_dashboard.php" class="btn back-btn">← Back to Dashboard</a>
        <a href="logout.php" class="btn logout-btn">Logout</a>
    </div>
</header>

<main>
    <a href="add_medicine.php" class="add-btn">+ Add New Medicine</a>

    <?php if ($result->num_rows > 0): ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Manufacturer</th>
                <th>Expiry Date</th>
                <th>Quantity</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($medicine = $result->fetch_assoc()): ?>
            <tr>
                <td data-label="ID"><?php echo htmlspecialchars($medicine['id']); ?></td>
                <td data-label="Name"><?php echo htmlspecialchars($medicine['name']); ?></td>
                <td data-label="Manufacturer"><?php echo htmlspecialchars($medicine['manufacturer']); ?></td>
                <td data-label="Expiry Date"><?php echo htmlspecialchars($medicine['expiry_date']); ?></td>
                <td data-label="Quantity" class="<?= $medicine['quantity'] <= 5 ? 'low-stock' : '' ?>">
                    <?php echo htmlspecialchars($medicine['quantity']); ?>
                </td>
                <td data-label="Action">
                    <a class="edit-btn" href="edit_medicine.php?id=<?php echo $medicine['id']; ?>">Edit</a>
                    <a class="delete-btn" href="manage_medicine.php?delete_id=<?php echo $medicine['id']; ?>" onclick="return confirm('Delete this medicine?');">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>No medicine records found.</p>
    <?php endif; ?>
</main>

<footer>
    <p>&copy; <?php echo date("Y"); ?> Medical Project Admin Panel</p>
</footer>

</body>
</html>

<?php
$conn->close();
?>
