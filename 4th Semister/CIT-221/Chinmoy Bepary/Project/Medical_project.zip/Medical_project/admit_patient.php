<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch doctors info
$doctors = [];
$sql = "SELECT id, name, specialization, available_days, available_time, visit_fee FROM doctors ORDER BY name ASC";
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $doctors[] = $row;
    }
}

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_patient'])) {
    $patient_name = trim($_POST['patient_name']);
    $patient_age = intval($_POST['patient_age']);
    $patient_gender = $_POST['patient_gender'];
    $phone = trim($_POST['phone']);
    $doctor_id = intval($_POST['doctor_id']);
    $admit_date = $_POST['admit_date'];

    if (empty($patient_name) || $patient_age <= 0 || empty($patient_gender) || empty($phone) || empty($doctor_id) || empty($admit_date)) {
        $error = "Please fill in all required fields correctly.";
    } else {
        // Calculate serial no for doctor & date
        $stmt = $conn->prepare("SELECT COUNT(*) as count FROM admissions WHERE doctor_id = ? AND admit_date = ?");
        $stmt->bind_param("is", $doctor_id, $admit_date);
        $stmt->execute();
        $result = $stmt->get_result();
        $serial_no = 1;
        if ($row = $result->fetch_assoc()) {
            $serial_no = $row['count'] + 1;
        }
        $stmt->close();

        // Insert admission
        $stmt = $conn->prepare("INSERT INTO admissions (user_id, patient_name, patient_age, patient_gender, phone, doctor_id, admit_date, serial_no) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isissisi", $user_id, $patient_name, $patient_age, $patient_gender, $phone, $doctor_id, $admit_date, $serial_no);

        if ($stmt->execute()) {
            $success = "Patient admitted successfully. Serial number: " . $serial_no;
        } else {
            $error = "Failed to admit patient. Please try again.";
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Admit Patient</title>
<style>
    /* (same styles as before, omitted here for brevity, just copy from previous code) */
    body {
        font-family: Arial, sans-serif;
        background-color: #f6f8fa;
        padding: 20px;
        color: #333;
    }
    h2 {
        text-align: center;
        color: #2c3e50;
    }
    form {
        max-width: 500px;
        margin: 20px auto;
        padding: 20px;
        background: white;
        border-radius: 10px;
        box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }
    label {
        display: block;
        margin-top: 15px;
        font-weight: bold;
    }
    input[type="text"],
    input[type="number"],
    input[type="date"],
    select {
        width: 100%;
        padding: 10px;
        margin-top: 5px;
        border: 1px solid #ccc;
        border-radius: 6px;
        box-sizing: border-box;
    }
    button {
        margin-top: 20px;
        background-color: #2980b9;
        color: white;
        padding: 12px 20px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        width: 100%;
        font-size: 16px;
    }
    button:hover {
        background-color: #3498db;
    }
    .success {
        color: green;
        font-weight: bold;
        text-align: center;
    }
    .error {
        color: red;
        font-weight: bold;
        text-align: center;
    }
    .doctor-info {
        background: #f1f1f1;
        padding: 10px;
        border-radius: 8px;
        margin-top: 10px;
    }
    .nav-buttons {
        text-align: center;
        margin-top: 30px;
    }
    .nav-buttons a {
        display: inline-block;
        margin: 5px 10px;
        padding: 10px 15px;
        background-color: #7f8c8d;
        color: white;
        text-decoration: none;
        border-radius: 5px;
    }
    .nav-buttons a:hover {
        background-color: #95a5a6;
    }
    .download-btn {
        background-color: #27ae60;
        padding: 12px 20px;
        border-radius: 6px;
        color: white;
        font-weight: bold;
        border: none;
        cursor: pointer;
        width: 100%;
        font-size: 16px;
        margin-top: 15px;
    }
    .download-btn:hover {
        background-color: #2ecc71;
    }
    .serial-list-btn {
        background-color: #2980b9;
        padding: 12px 20px;
        border-radius: 6px;
        color: white;
        font-weight: bold;
        border: none;
        cursor: pointer;
        width: 100%;
        font-size: 16px;
        margin-top: 15px;
        text-decoration: none;
        display: inline-block;
        text-align: center;
    }
    .serial-list-btn:hover {
        background-color: #3498db;
    }
</style>
</head>
<body>

<h2>Admit Patient</h2>

<?php if ($error): ?>
    <p class="error"><?= htmlspecialchars($error) ?></p>
<?php endif; ?>

<?php if ($success): ?>
    <p class="success"><?= htmlspecialchars($success) ?></p>

    <!-- Download Admit PDF form -->
    <form action="admission_slip_pdf.php" method="post" target="_blank">
        <input type="hidden" name="patient_name" value="<?= htmlspecialchars($patient_name) ?>">
        <input type="hidden" name="patient_age" value="<?= htmlspecialchars($patient_age) ?>">
        <input type="hidden" name="patient_gender" value="<?= htmlspecialchars($patient_gender) ?>">
        <input type="hidden" name="phone" value="<?= htmlspecialchars($phone) ?>">
        <input type="hidden" name="doctor_id" value="<?= htmlspecialchars($doctor_id) ?>">
        <input type="hidden" name="admit_date" value="<?= htmlspecialchars($admit_date) ?>">
        <input type="hidden" name="serial_no" value="<?= htmlspecialchars($serial_no) ?>">
        <button type="submit" class="download-btn">Download Admission Receipt (PDF)</button>
    </form>

    <!-- Button to view serial list -->
    <div style="max-width:500px; margin:20px auto; text-align:center;">
        <a href="serial_list.php" class="serial-list-btn">View Serial List</a>
    </div>
<?php endif; ?>

<form method="POST" action="">
    <label>Patient Name:</label>
    <input type="text" name="patient_name" required value="<?= isset($patient_name) ? htmlspecialchars($patient_name) : '' ?>">
    
    <label>Age:</label>
    <input type="number" name="patient_age" required value="<?= isset($patient_age) ? (int)$patient_age : '' ?>">

    <label>Gender:</label>
    <select name="patient_gender" required>
        <option value="">-- Select --</option>
        <option value="Male" <?= (isset($patient_gender) && $patient_gender == "Male") ? "selected" : "" ?>>Male</option>
        <option value="Female" <?= (isset($patient_gender) && $patient_gender == "Female") ? "selected" : "" ?>>Female</option>
        <option value="Other" <?= (isset($patient_gender) && $patient_gender == "Other") ? "selected" : "" ?>>Other</option>
    </select>

    <label>Phone:</label>
    <input type="text" name="phone" required value="<?= isset($phone) ? htmlspecialchars($phone) : '' ?>">

    <label>Doctor:</label>
    <select name="doctor_id" id="doctorSelect" onchange="showDoctorInfo()" required>
        <option value="">-- Select Doctor --</option>
        <?php foreach ($doctors as $doc): ?>
            <option 
                value="<?= $doc['id'] ?>"
                data-name="<?= htmlspecialchars($doc['name']) ?>"
                data-specialization="<?= htmlspecialchars($doc['specialization']) ?>"
                data-days="<?= htmlspecialchars($doc['available_days']) ?>"
                data-time="<?= htmlspecialchars($doc['available_time']) ?>"
                data-fee="<?= htmlspecialchars($doc['visit_fee']) ?>"
                <?= (isset($doctor_id) && $doctor_id == $doc['id']) ? "selected" : "" ?>
            >
                <?= htmlspecialchars($doc['name'] . " (" . $doc['specialization'] . ")") ?>
            </option>
        <?php endforeach; ?>
    </select>

    <div id="doctorInfo" class="doctor-info" style="display:none;">
        <div><strong>Available Days:</strong> <span id="days"></span></div>
        <div><strong>Time:</strong> <span id="time"></span></div>
        <div><strong>Fee:</strong> <span id="fee"></span> ৳</div>
    </div>

    <label>Admit Date:</label>
    <input type="date" name="admit_date" value="<?= isset($admit_date) ? htmlspecialchars($admit_date) : date('Y-m-d') ?>" required>

    <button type="submit" name="submit_patient">Admit Patient</button>
</form>

<div class="nav-buttons">
    <a href="index.php">← Back to Homepage</a>
</div>

<script>
function showDoctorInfo() {
    const select = document.getElementById('doctorSelect');
    const option = select.options[select.selectedIndex];
    const infoDiv = document.getElementById('doctorInfo');

    if (select.value === "") {
        infoDiv.style.display = 'none';
        return;
    }

    document.getElementById('days').textContent = option.getAttribute('data-days');
    document.getElementById('time').textContent = option.getAttribute('data-time');
    document.getElementById('fee').textContent = option.getAttribute('data-fee');
    infoDiv.style.display = 'block';
}
// Call once on page load if doctor already selected
window.onload = function() {
    showDoctorInfo();
}
</script>

</body>
</html>
