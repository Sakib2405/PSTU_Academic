<?php
$servername = "localhost";
$username = "root";        // change if needed
$password = "";            // change if needed
$database = "medical_project";  // your database name

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
