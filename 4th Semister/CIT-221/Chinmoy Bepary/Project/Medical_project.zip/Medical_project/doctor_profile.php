<?php
include 'db_connect.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Invalid doctor ID.";
    exit();
}

$id = intval($_GET['id']);

// Fetch doctor info
$stmt = $conn->prepare("SELECT name, specialization, email, qualification, picture_path, available_days, available_time, room_no, visit_fee FROM doctors WHERE id = ?");
if (!$stmt) {
    die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
}
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Doctor not found.";
    exit();
}

$doctor = $result->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Doctor Profile - <?= htmlspecialchars($doctor['name']) ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 30px auto;
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
        }
        .profile-header {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .profile-pic {
            width: 180px;
            height: 180px;
            object-fit: cover;
            border-radius: 50%;
            border: 2px solid #007bff;
        }
        h1 {
            margin-bottom: 5px;
        }
        .info {
            font-size: 16px;
            color: #333;
        }
        .qualification-info {
            margin-top: 25px;
            background: white;
            padding: 15px;
            border-radius: 6px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            white-space: pre-line;
        }
        a.back-link {
            display: inline-block;
            margin-top: 25px;
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }
        a.back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="profile-header">
        <?php
        $uploadPath = 'images/';
        $defaultImage = 'images/default.png';
        $imageFile = !empty($doctor['picture_path']) && file_exists($uploadPath . $doctor['picture_path']) 
                     ? $uploadPath . $doctor['picture_path'] 
                     : $defaultImage;
        ?>
        <img src="<?= htmlspecialchars($imageFile) ?>" alt="Dr. <?= htmlspecialchars($doctor['name']) ?>" class="profile-pic" />

        <div>
            <h1>Dr. <?= htmlspecialchars($doctor['name']) ?></h1>
            <p class="info"><strong>Specialization:</strong> <?= htmlspecialchars($doctor['specialization']) ?></p>
            <p class="info"><strong>Email:</strong> <?= htmlspecialchars($doctor['email']) ?></p>
            <p class="info"><strong>Available Days:</strong> <?= htmlspecialchars($doctor['available_days']) ?></p>
            <p class="info"><strong>Time Slot:</strong> <?= htmlspecialchars($doctor['available_time']) ?></p>
            <p class="info"><strong>Room No.:</strong> <?= htmlspecialchars($doctor['room_no']) ?></p>
            <p class="info"><strong>Visit Fee:</strong> ৳<?= number_format($doctor['visit_fee'], 2) ?></p>
        </div>
    </div>

    <h2>Qualification</h2>
    <div class="qualification-info">
        <?= nl2br(htmlspecialchars($doctor['qualification'])) ?>
    </div>

    <a href="doctors_serial.php" class="back-link">← Back to Doctor List</a>

</body>
</html>

<?php
$conn->close();
?>
