<?php
session_start();

include 'db_connect.php';

if (!isset($_SESSION['admin_name'])) {
    header("Location: admin_login.php");
    exit();
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
    echo "Invalid serial ID.";
    exit();
}

$error = "";
$success = "";

// Fetch current serial info (including serial_no)
$stmt = $conn->prepare("SELECT * FROM admissions WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$serial = $result->fetch_assoc();
$stmt->close();

if (!$serial) {
    echo "Serial not found.";
    exit();
}

// Fetch doctors
$doctors = [];
$sql = "SELECT id, name FROM doctors ORDER BY name ASC";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    $doctors[] = $row;
}

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $serial_no = isset($_POST['serial_no']) ? intval($_POST['serial_no']) : 0;
    $patient_name = trim($_POST['patient_name']);
    $patient_age = intval($_POST['patient_age']);
    $patient_gender = $_POST['patient_gender'];
    $phone = trim($_POST['phone']);
    $doctor_id = intval($_POST['doctor_id']);
    $admit_date = $_POST['admit_date'];

    if (
        $serial_no <= 0 || 
        empty($patient_name) || 
        $patient_age <= 0 || 
        empty($patient_gender) || 
        empty($phone) || 
        empty($doctor_id) || 
        empty($admit_date) ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/', $admit_date)
    ) {
        $error = "Please fill in all required fields with valid data, including a proper date (YYYY-MM-DD).";
    } else {
        $stmt = $conn->prepare("UPDATE admissions SET serial_no = ?, patient_name = ?, patient_age = ?, patient_gender = ?, phone = ?, doctor_id = ?, admit_date = ? WHERE id = ?");
        $stmt->bind_param("isissisi", $serial_no, $patient_name, $patient_age, $patient_gender, $phone, $doctor_id, $admit_date, $id);

        if ($stmt->execute()) {
            $success = "Serial updated successfully.";

            // Refresh serial data after update
            $stmt->close();
            $stmt = $conn->prepare("SELECT * FROM admissions WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();
            $serial = $result->fetch_assoc();
            $stmt->close();
        } else {
            $error = "Failed to update serial: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Edit Serial</title>
    <link rel="stylesheet" href="admin_dashboard.css" />
</head>
<body>
    <div class="container">
        <h2>Edit Serial</h2>

        <?php if ($error): ?>
            <p class="error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <?php if ($success): ?>
            <p class="success"><?= htmlspecialchars($success) ?></p>
        <?php endif; ?>

        <form method="post">
            <label>Serial Number:</label>
            <input type="number" name="serial_no" value="<?= htmlspecialchars($serial['serial_no']) ?>" min="1" required>

            <label>Patient Name:</label>
            <input type="text" name="patient_name" value="<?= htmlspecialchars($serial['patient_name']) ?>" required>

            <label>Age:</label>
            <input type="number" name="patient_age" value="<?= intval($serial['patient_age']) ?>" required>

            <label>Gender:</label>
            <select name="patient_gender" required>
                <option value="Male" <?= $serial['patient_gender'] === 'Male' ? 'selected' : '' ?>>Male</option>
                <option value="Female" <?= $serial['patient_gender'] === 'Female' ? 'selected' : '' ?>>Female</option>
                <option value="Other" <?= $serial['patient_gender'] === 'Other' ? 'selected' : '' ?>>Other</option>
            </select>

            <label>Phone:</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($serial['phone']) ?>" required>

            <label>Doctor:</label>
            <select name="doctor_id" required>
                <?php foreach ($doctors as $doc): ?>
                    <option value="<?= $doc['id'] ?>" <?= $doc['id'] == $serial['doctor_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($doc['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Admit Date:</label>
            <input type="date" name="admit_date" value="<?= htmlspecialchars($serial['admit_date']) ?>" required>

            <button type="submit">Update Serial</button>
        </form>

        <a href="manage_serials.php" class="back-btn">← Back to Serial List</a>
    </div>
</body>
</html>
