<?php
include 'db_connect.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Insert into database
    $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";
    
    if ($conn->query($sql) === TRUE) {
        // Registration success - Redirect to home page
        echo "Registration successful. Redirecting to <a href='index.php'>Home Page</a>...";
        header("refresh:3;url=index.php");  // Redirect to home after 3 seconds
    } else {
        // Error in registration
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Medical Project</title>
    <link rel="stylesheet" href="register.css"> <!-- Link to CSS file -->
</head>
<body>

<!-- Registration Form -->
<form method="post" action="register.php">
    <h2>Register</h2>
    <label for="name">Name:</label>
    <input type="text" name="name" id="name" required>
    
    <label for="email">Email:</label>
    <input type="email" name="email" id="email" required>
    
    <label for="password">Password:</label>
    <input type="password" name="password" id="password" required>
    
    <button type="submit">Register</button>
</form>

<!-- Login Link -->
<p>Already have an account? <a href="login.php">Login here</a></p>

<!-- Optional Link to Home Page -->
<p>Back to <a href="index.php">Home</a></p>

</body>
</html>
