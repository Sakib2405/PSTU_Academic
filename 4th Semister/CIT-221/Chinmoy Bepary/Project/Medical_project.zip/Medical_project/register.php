<?php
include 'db_connect.php'; // Ensure this file sets up $conn properly

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate form data
    $name = trim($_POST['name']);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Prepare and bind to avoid SQL injection
    $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("sss", $name, $email, $password);

        if ($stmt->execute()) {
            echo "<div class='success'>Registration successful. Redirecting to <a href='index.php'>Home Page</a>...</div>";
            header("refresh:3;url=index.php");
        } else {
            echo "<div class='error'>Error: " . $stmt->error . "</div>";
        }

        $stmt->close();
    } else {
        echo "<div class='error'>Error preparing statement: " . $conn->error . "</div>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Medical Project</title>
    <link rel="stylesheet" href="register.css">
</head>
<body>

<div class="register-container">
    <form method="post" action="register.php">
        <h2>Register</h2>
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" required>
        
        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>
        
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required>
        
        <button type="submit">Register</button>

        <p>Already have an account? <a href="login.php">Login here</a></p>
        <p>Back to <a href="index.php">Home</a></p>
    </form>
</div>

</body>
</html>
