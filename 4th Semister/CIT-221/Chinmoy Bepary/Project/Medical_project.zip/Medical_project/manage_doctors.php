<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['admin_name'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $stmt = $conn->prepare("DELETE FROM doctors WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_doctors.php");
    exit();
}

$result = $conn->query("SELECT id, name, specialization, email, available_time, available_days, room_no, visit_fee FROM doctors ORDER BY id DESC");

if (!$result) {
    die("Query Failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Manage Doctors - Admin</title>
    <link rel="stylesheet" href="manage_doctors.css" />
</head>
<body>

<header>
    <h1>Manage Doctors</h1>
    <a href="admin_dashboard.php" class="btn back-btn">← Back to Dashboard</a>
    <a href="add_doctor.php" class="btn add-btn">+ Add Doctor</a>
    <a href="logout.php" class="btn logout-btn">Logout</a>
</header>

<main>
    <?php if ($result->num_rows > 0): ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Specialization</th>
                <th>Email</th>
                <th>Available Time</th>
                <th>Available Days</th>
                <th>Room No.</th>
                <th>Visit Fee (৳)</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($doctor = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($doctor['id']) ?></td>
                <td><?= htmlspecialchars($doctor['name']) ?></td>
                <td><?= htmlspecialchars($doctor['specialization']) ?></td>
                <td><?= htmlspecialchars($doctor['email']) ?></td>
                <td><?= htmlspecialchars($doctor['available_time']) ?></td>
                <td><?= htmlspecialchars($doctor['available_days']) ?></td>
                <td><?= htmlspecialchars($doctor['room_no']) ?></td>
                <td><?= number_format($doctor['visit_fee'], 2) ?></td>
                <td>
                    <a class="edit-btn" href="edit_doctor.php?id=<?= $doctor['id'] ?>">Edit</a>
                    <a class="delete-btn" href="manage_doctors.php?delete_id=<?= $doctor['id'] ?>" onclick="return confirm('Delete this doctor?');">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>No doctors found.</p>
    <?php endif; ?>
</main>

<footer>
    <p>&copy; <?= date("Y") ?> Medical Project Admin Panel</p>
</footer>

</body>
</html>

<?php $conn->close(); ?>
