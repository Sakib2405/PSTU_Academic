<?php
require('fpdf.php');

// Check if required POST data is present
if (
    !isset($_POST['patient_name']) ||
    !isset($_POST['patient_age']) ||
    !isset($_POST['patient_gender']) ||
    !isset($_POST['phone']) ||
    !isset($_POST['doctor_id']) ||
    !isset($_POST['admit_date']) ||
    !isset($_POST['serial_no'])
) {
    die('No admission data found.');
}

// Sanitize and assign POST data
$data = [
    'name'    => htmlspecialchars($_POST['patient_name']),
    'age'     => htmlspecialchars($_POST['patient_age']),
    'gender'  => htmlspecialchars($_POST['patient_gender']),
    'phone'   => htmlspecialchars($_POST['phone']),
    'doctor'  => '',  // Will fetch from DB below
    'days'    => '',
    'time'    => '',
    'fee'     => '',
    'date'    => htmlspecialchars($_POST['admit_date']),
    'serial'  => htmlspecialchars($_POST['serial_no']),
    'payment' => 'Pending'  // You can change if you track payment status
];

// Fetch doctor details from database using doctor_id
$doctor_id = intval($_POST['doctor_id']);
$conn = new mysqli('localhost', 'root', '', 'medical_project');
if ($conn->connect_error) {
    die('Database connection failed: ' . $conn->connect_error);
}

$stmt = $conn->prepare("SELECT name, available_days, available_time, visit_fee FROM doctors WHERE id = ?");
$stmt->bind_param("i", $doctor_id);
$stmt->execute();
$stmt->bind_result($doc_name, $doc_days, $doc_time, $doc_fee);
if ($stmt->fetch()) {
    $data['doctor'] = htmlspecialchars($doc_name);
    $data['days'] = htmlspecialchars($doc_days);
    $data['time'] = htmlspecialchars($doc_time);
    $data['fee'] = htmlspecialchars($doc_fee);
}
$stmt->close();
$conn->close();

class PDF extends FPDF {
    // Header of the page
    function Header() {
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 10, 'Patient Admission Receipt', 0, 1, 'C');
        $this->Ln(5);
    }

    // Footer of the page
    function Footer() {
        $this->SetY(-20);
        $this->SetFont('Arial', 'I', 10);
        $this->Cell(0, 10, 'Powered by Your Clinic System', 0, 0, 'C');
    }
}

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// Patient & Doctor Info
$pdf->Cell(50, 10, 'Patient Name:', 0, 0);
$pdf->Cell(100, 10, $data['name'], 0, 1);

$pdf->Cell(50, 10, 'Age:', 0, 0);
$pdf->Cell(100, 10, $data['age'], 0, 1);

$pdf->Cell(50, 10, 'Gender:', 0, 0);
$pdf->Cell(100, 10, $data['gender'], 0, 1);

$pdf->Cell(50, 10, 'Phone:', 0, 0);
$pdf->Cell(100, 10, $data['phone'], 0, 1);

$pdf->Cell(50, 10, 'Doctor:', 0, 0);
$pdf->Cell(100, 10, $data['doctor'], 0, 1);

$pdf->Cell(50, 10, 'Available Days:', 0, 0);
$pdf->Cell(100, 10, $data['days'], 0, 1);

$pdf->Cell(50, 10, 'Available Time:', 0, 0);
$pdf->Cell(100, 10, $data['time'], 0, 1);

$pdf->Cell(50, 10, 'Visit Fee:', 0, 0);
$pdf->Cell(100, 10, $data['fee'] . ' BDT', 0, 1);

$pdf->Cell(50, 10, 'Admit Date:', 0, 0);
$pdf->Cell(100, 10, $data['date'], 0, 1);

$pdf->Cell(50, 10, 'Serial No:', 0, 0);
$pdf->Cell(100, 10, '#' . $data['serial'], 0, 1);

$pdf->Cell(50, 10, 'Payment Status:', 0, 0);
$pdf->Cell(100, 10, $data['payment'], 0, 1);

// Signature Section
$pdf->Ln(15);
$pdf->Cell(0, 10, 'Authorized Signature:', 0, 1, 'L');

$signaturePath = 'images/signature.png'; // Path to your signature image

if (file_exists($signaturePath)) {
    $pdf->Image($signaturePath, 10, $pdf->GetY(), 50);
    $pdf->Ln(30);
} else {
    $pdf->Cell(0, 10, '[Signature image not found]', 0, 1, 'L');
}

$pdf->Ln(5);
$pdf->SetFont('Arial', 'I', 10);
$pdf->Cell(0, 10, 'This document is auto-generated and valid for clinic verification.', 0, 1, 'C');

$pdf->Output('I', 'Admission_Receipt.pdf');
