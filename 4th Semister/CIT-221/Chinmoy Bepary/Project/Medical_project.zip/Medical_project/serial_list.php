<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch admissions joined with doctor info
$sql = "SELECT a.id, a.patient_name, a.patient_age, a.patient_gender, a.phone, a.admit_date, a.serial_no,
        d.name as doctor_name, d.specialization
        FROM admissions a
        JOIN doctors d ON a.doctor_id = d.id
        ORDER BY a.admit_date DESC, a.serial_no ASC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admit Patient List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 900px;
            margin: 30px auto;
            padding: 0 15px;
            background: #f9f9f9;
        }
        h2 {
            text-align: center;
            color: #2c3e50;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
            background: white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #2980b9;
            color: white;
        }
        tr:nth-child(even) {
            background: #f2f6fc;
        }
        a.back-button {
            display: inline-block;
            margin-bottom: 15px;
            padding: 10px 18px;
            background: #7f8c8d;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }
        a.back-button:hover {
            background: #2c3e50;
        }
        .download-btn {
            margin-top: 15px;
            display: inline-block;
            background: #27ae60;
            color: white;
            padding: 10px 18px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            float: right;
        }
        .download-btn:hover {
            background: #1e8449;
        }
    </style>
</head>
<body>

<a href="index.php" class="back-button">← Back to Homepage</a>
<h2>Admit Patient List</h2>

<a href="admit_patient_pdf.php" class="download-btn" target="_blank">Download PDF</a>


<table>
    <thead>
        <tr>
            <th>Serial No</th>
            <th>Patient Name</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Phone</th>
            <th>Doctor</th>
            <th>Specialization</th>
            <th>Admit Date</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['serial_no']) ?></td>
                    <td><?= htmlspecialchars($row['patient_name']) ?></td>
                    <td><?= htmlspecialchars($row['patient_age']) ?></td>
                    <td><?= htmlspecialchars($row['patient_gender']) ?></td>
                    <td><?= htmlspecialchars($row['phone']) ?></td>
                    <td><?= htmlspecialchars($row['doctor_name']) ?></td>
                    <td><?= htmlspecialchars($row['specialization']) ?></td>
                    <td><?= htmlspecialchars($row['admit_date']) ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="8" style="text-align:center;">No admissions found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

</body>
</html>
<?php
$conn->close();
?>
