<?php
include 'db_connect.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid doctor ID.");
}

$id = intval($_GET['id']);
$doctor = [];

// Fetch current doctor data
$stmt = $conn->prepare("SELECT * FROM doctors WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    die("Doctor not found.");
}
$doctor = $result->fetch_assoc();
$stmt->close();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'];
    $specialization = $_POST['specialization'];
    $email = trim($_POST['email']);
    $email = $email === '' ? null : $email;  // Set to null if empty

    $qualification = $_POST['qualification'];
    $available_days = $_POST['available_days'];
    $available_time = $_POST['available_time'];
    $room_no = $_POST['room_no'];
    $visit_fee = floatval($_POST['visit_fee']);
    
    // Handle image upload
    $picture_path = $doctor['picture_path'];
    if (!empty($_FILES['picture']['name'])) {
        $target_dir = "images/";
        $new_file = basename($_FILES["picture"]["name"]);
        $target_file = $target_dir . time() . "_" . $new_file;
        if (move_uploaded_file($_FILES["picture"]["tmp_name"], $target_file)) {
            $picture_path = basename($target_file); // Only filename stored
        }
    }

    // Update the doctor
    $stmt = $conn->prepare("UPDATE doctors SET name=?, specialization=?, email=?, qualification=?, available_days=?, available_time=?, room_no=?, visit_fee=?, picture_path=? WHERE id=?");
    $stmt->bind_param("sssssssisi", $name, $specialization, $email, $qualification, $available_days, $available_time, $room_no, $visit_fee, $picture_path, $id);

    if ($stmt->execute()) {
        header("Location: manage_doctors.php?id=$id");
        exit();
    } else {
        echo "Error updating doctor: " . $stmt->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Doctor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
            background: #f4f4f4;
            border-radius: 8px;
        }
        form {
            background: white;
            padding: 20px;
            border-radius: 6px;
            box-shadow: 0 0 8px rgba(0,0,0,0.1);
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 15px;
        }
        input, textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
        }
        input[type="file"] {
            padding: 5px;
        }
        button {
            margin-top: 20px;
            padding: 10px 18px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
        }
        .current-pic {
            margin-top: 10px;
        }
    </style>
</head>
<body>

<h2>Edit Doctor</h2>

<form method="post" enctype="multipart/form-data">
    <label>Name:</label>
    <input type="text" name="name" value="<?= htmlspecialchars($doctor['name']) ?>" required>

    <label>Specialization:</label>
    <input type="text" name="specialization" value="<?= htmlspecialchars($doctor['specialization']) ?>" required>

    <label>Email: <small>(optional)</small></label>
    <input type="email" name="email" value="<?= htmlspecialchars($doctor['email']) ?>">

    <label>Qualification:</label>
    <textarea name="qualification" rows="4" required><?= htmlspecialchars($doctor['qualification']) ?></textarea>

    <label>Available Days:</label>
    <input type="text" name="available_days" value="<?= htmlspecialchars($doctor['available_days']) ?>" required>

    <label>Available Time:</label>
    <input type="text" name="available_time" value="<?= htmlspecialchars($doctor['available_time']) ?>" required>

    <label>Room No.:</label>
    <input type="text" name="room_no" value="<?= htmlspecialchars($doctor['room_no']) ?>" required>

    <label>Visit Fee (৳):</label>
    <input type="number" step="0.01" name="visit_fee" value="<?= htmlspecialchars($doctor['visit_fee']) ?>" required>

    <label>Change Picture:</label>
    <input type="file" name="picture" accept="image/*">
    <?php if (!empty($doctor['picture_path'])): ?>
        <div class="current-pic">
            <strong>Current Picture:</strong><br>
            <img src="images/<?= htmlspecialchars($doctor['picture_path']) ?>" width="100" height="100" style="border-radius: 50%;">
        </div>
    <?php endif; ?>

    <button type="submit">Update Doctor</button>
</form>

</body>
</html>
