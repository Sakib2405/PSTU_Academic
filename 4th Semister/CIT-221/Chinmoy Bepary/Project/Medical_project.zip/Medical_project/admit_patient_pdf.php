<?php
session_start();
include 'db_connect.php';
require_once 'fpdf.php';  // Make sure this path matches where your fpdf.php is

class PDF extends FPDF {
    // Page header
    function Header() {
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 10, 'Admit Patient List', 0, 1, 'C');
        $this->Ln(5);
    }

    // Page footer
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page '.$this->PageNo(), 0, 0, 'C');
    }
}

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 12);

// Table header
$header = ['Serial', 'Patient Name', 'Age', 'Gender', 'Phone', 'Doctor', 'Specialization', 'Admit Date'];
$w = [15, 40, 15, 20, 30, 40, 40, 30]; // column widths

foreach ($header as $i => $col) {
    $pdf->Cell($w[$i], 10, $col, 1, 0, 'C');
}
$pdf->Ln();

// Fetch admissions with doctor info
$sql = "SELECT a.serial_no, a.patient_name, a.patient_age, a.patient_gender, a.phone, a.admit_date,
               d.name as doctor_name, d.specialization
        FROM admissions a
        JOIN doctors d ON a.doctor_id = d.id
        ORDER BY a.admit_date DESC, a.serial_no ASC";

$result = $conn->query($sql);

$pdf->SetFont('Arial', '', 11);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell($w[0], 8, $row['serial_no'], 1);
        $pdf->Cell($w[1], 8, $row['patient_name'], 1);
        $pdf->Cell($w[2], 8, $row['patient_age'], 1, 0, 'C');
        $pdf->Cell($w[3], 8, $row['patient_gender'], 1, 0, 'C');
        $pdf->Cell($w[4], 8, $row['phone'], 1);
        $pdf->Cell($w[5], 8, $row['doctor_name'], 1);
        $pdf->Cell($w[6], 8, $row['specialization'], 1);
        $pdf->Cell($w[7], 8, $row['admit_date'], 1);
        $pdf->Ln();
    }
} else {
    $pdf->Cell(array_sum($w), 8, 'No admissions found.', 1, 0, 'C');
}

$pdf->Output('I', 'admit_patient_list.pdf');

$conn->close();
?>
