<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'];
    $specialization = $_POST['specialization'];
    $email = trim($_POST['email']);
    $email = $email === '' ? null : $email;

    $qualification = $_POST['qualification'];
    $available_days = $_POST['available_days'];
    $available_time = $_POST['available_time'];
    $room_no = $_POST['room_no'];
    $visit_fee = floatval($_POST['visit_fee']);

    $picture_path = null;
    if (!empty($_FILES['picture']['name'])) {
        $target_dir = "images/";
        $new_file = basename($_FILES["picture"]["name"]);
        $target_file = $target_dir . time() . "_" . $new_file;

        if (move_uploaded_file($_FILES["picture"]["tmp_name"], $target_file)) {
            $picture_path = basename($target_file);
        }
    }

    $stmt = $conn->prepare("INSERT INTO doctors (name, specialization, email, qualification, available_days, available_time, room_no, visit_fee, picture_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssds", $name, $specialization, $email, $qualification, $available_days, $available_time, $room_no, $visit_fee, $picture_path);

    if ($stmt->execute()) {
        header("Location: manage_doctors.php");
        exit();
    } else {
        echo "Error adding doctor: " . $stmt->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Doctor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
            background: #f4f4f4;
            border-radius: 8px;
        }
        form {
            background: white;
            padding: 20px;
            border-radius: 6px;
            box-shadow: 0 0 8px rgba(0,0,0,0.1);
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 15px;
        }
        input, textarea {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
        }
        input[type="file"] {
            padding: 5px;
        }
        button {
            margin-top: 20px;
            padding: 10px 18px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
        }
    </style>
</head>
<body>

<h2>Add New Doctor</h2>

<form method="post" enctype="multipart/form-data">
    <label>Name:</label>
    <input type="text" name="name" required>

    <label>Specialization:</label>
    <input type="text" name="specialization" required>

    <label>Email: <small>(optional)</small></label>
    <input type="email" name="email">

    <label>Qualification:</label>
    <textarea name="qualification" rows="4" required></textarea>

    <label>Available Days:</label>
    <input type="text" name="available_days" required>

    <label>Available Time:</label>
    <input type="text" name="available_time" required>

    <label>Room No.:</label>
    <input type="text" name="room_no" required>

    <label>Visit Fee (৳):</label>
    <input type="number" step="0.01" name="visit_fee" required>

    <label>Upload Picture:</label>
    <input type="file" name="picture" accept="image/*">

    <button type="submit">Add Doctor</button>
</form>

</body>
</html>
