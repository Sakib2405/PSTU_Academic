<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['admin_name'])) {
    header("Location: admin_login.php");
    exit();
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
    echo "Invalid serial ID.";
    exit();
}

// Delete the serial
$stmt = $conn->prepare("DELETE FROM admissions WHERE id = ?");
$stmt->bind_param("i", $id);
if ($stmt->execute()) {
    $stmt->close();
    $conn->close();
    header("Location: manage_serials.php?msg=deleted");
    exit();
} else {
    echo "Failed to delete serial.";
    $stmt->close();
    $conn->close();
}
