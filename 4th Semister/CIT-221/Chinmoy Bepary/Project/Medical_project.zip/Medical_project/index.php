<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical Project</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <h1>Welcome to the Medical Project</h1>
    </header>

    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="information.html">Information</a></li>
            <li><a href="medicine.html">Medicine</a></li>
            <li><a href="doctors.html">Doctors</a></li>
            <li><a href="doctor_serial.html">Doctor Serial</a></li>
            <li><a href="emergency.html">Emergency</a></li>
            <li><a href="admitted_patients.html">Admitted Patients</a></li>
            <li><a href="blood_donation.html">Blood Bank</a></li>
        </ul>
    </nav>

    <main>
        <?php
        if (isset($_SESSION['user'])) {
            echo "<p class='welcome-message'>Welcome, " . htmlspecialchars($_SESSION['user']) . "! <a href='logout.php' class='btn logout-btn'>Logout</a></p>";
        } else {
            echo "<p class='login-message'>You are not logged in. <a href='login.php' class='btn'>Login</a> or <a href='register.php' class='btn'>Register</a></p>";
            echo "<div class='image-container'><img src='images/index.webp' alt='Login Required'></div>";  // Add the image below
        }
        ?>
    </main>

</body>
</html>
