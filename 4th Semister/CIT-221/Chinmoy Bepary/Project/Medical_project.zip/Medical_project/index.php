<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical Project</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Welcome to the Medical Project</h1>
</header>

<nav>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="information.html">Information</a></li>
        <li><a href="medicine.html">Medicine</a></li>
        <li><a href="doctors_serial.php">Doctor Serial</a></li>
        <li><a href="emergency.html">Emergency</a></li>
        <li><a href="blood_donation.html">Blood Bank</a></li>
        <li><a href="admit_patient.php">Admit Patient</a></li>
    </ul>
</nav>

<main>
    <?php
    if (isset($_SESSION['user'])) {
        echo "<p class='welcome-message'>Welcome, " . htmlspecialchars($_SESSION['user']) . "! <a href='logout.php' class='btn logout-btn'>Logout</a></p>";
    } elseif (isset($_SESSION['admin_name'])) {
        echo "<p class='welcome-message'>Admin: " . htmlspecialchars($_SESSION['admin_name']) . "! <a href='admin_dashboard.php' class='btn'>Dashboard</a> | <a href='logout.php' class='btn logout-btn'>Logout</a></p>";
    } else {
        echo "<p class='login-message'>You are not logged in.</p>";
        echo "<p><a href='login.php' class='btn'>User Login</a> or <a href='register.php' class='btn'>Register</a></p>";
        echo "<p><a href='admin_login.php' class='btn admin-btn'>Admin Login</a></p>";
        echo "<div class='image-container'><img src='images/index.webp' alt='Login Required'></div>";
    }
    ?>
</main>

</body>
</html>
