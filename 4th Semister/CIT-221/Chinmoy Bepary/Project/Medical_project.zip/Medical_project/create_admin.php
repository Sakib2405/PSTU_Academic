<?php
include 'db_connect.php';

$name = "Admin";
$email = "admin@example.com";
$password = password_hash("admin123", PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO admins (name, email, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $password);

if ($stmt->execute()) {
    echo "Admin user created.";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
