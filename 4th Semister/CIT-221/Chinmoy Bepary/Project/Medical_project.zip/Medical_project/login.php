<?php
session_start();
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Query the database for user data
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // User found, verify password
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            // Password matches, set session and redirect
            $_SESSION['user'] = $row['name'];  // Set session variable for user
            header("Location: index.php"); // Redirect to home after successful login
            exit();
        } else {
            $error_message = "Incorrect password.";
        }
    } else {
        $error_message = "No user found with that email.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Medical Project</title>
    <link rel="stylesheet" href="login.css"> <!-- Link to CSS file -->
</head>
<body>

<!-- Login Form -->
<form method="post" action="login.php">
    <h2>Login</h2>

    <!-- Display error message if login fails -->
    <?php if (isset($error_message)): ?>
        <p class="error"><?php echo $error_message; ?></p>
    <?php endif; ?>

    <label for="email">Email:</label>
    <input type="email" name="email" id="email" required>
    
    <label for="password">Password:</label>
    <input type="password" name="password" id="password" required>
    
    <button type="submit">Login</button>
</form>

<!-- Registration Link -->
<p>Don't have an account? <a href="register.php">Register here</a></p>

<!-- Optional Link to Home Page -->
<p>Back to <a href="index.php">Home</a></p>

</body>
</html>
