<?php
session_start();
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $sql = "SELECT id, name, password, role FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Database error: " . $conn->error); // Helpful for debugging
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user'] = $row['name'];
            $_SESSION['is_admin'] = ($row['role'] === 'admin'); // <-- now sets admin flag

            header("Location: profile.php");
            exit();
        } else {
            $error_message = "Incorrect password.";
        }
    } else {
        $error_message = "No user found with that email.";
    }

    $stmt->close();
}
$conn->close();
?>
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Login - Medical Project</title>
    <link rel="stylesheet" href="login.css" />
</head>
<body>
<form method="post" action="login.php" class="login-form">
    <h2>Login</h2>

    <?php if (isset($error_message)): ?>
        <p class="error"><?= htmlspecialchars($error_message) ?></p>
    <?php endif; ?>

    <label for="email">Email:</label>
    <input type="email" name="email" id="email" required />

    <label for="password">Password:</label>
    <input type="password" name="password" id="password" required />

    <button type="submit">Login</button>

    <p>Don't have an account? <a href="register.php">Register here</a></p>
    <p><a href="index.php">Back to Home</a></p>
</form>
</body>
</html>
