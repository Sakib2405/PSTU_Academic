<?php
session_start();
include 'db_connect.php';  // your DB connection file

// Check if admin is logged in
if (!isset($_SESSION['admin_name'])) {
    header("Location: admin_login.php");
    exit();
}

// Fetch total users count
$user_count = 0;
$result = $conn->query("SELECT COUNT(*) as total FROM users");
if ($result) {
    $row = $result->fetch_assoc();
    $user_count = $row['total'];
}

// Fetch total doctors count
$doctor_count = 0;
$result = $conn->query("SELECT COUNT(*) as total FROM doctors");
if ($result) {
    $row = $result->fetch_assoc();
    $doctor_count = $row['total'];
}

// Fetch medicine stock count (assuming table 'medicine' and column 'quantity')
$medicine_stock = 0;
$result = $conn->query("SELECT SUM(quantity) as total_stock FROM medicine");
if ($result) {
    $row = $result->fetch_assoc();
    $medicine_stock = $row['total_stock'] ?? 0;
}

// Fetch emergency cases count (assuming 'emergency_cases' table or a status column in admissions)
$emergency_count = 0;
$result = $conn->query("SELECT COUNT(*) as total FROM emergency_cases");
if ($result) {
    $row = $result->fetch_assoc();
    $emergency_count = $row['total'];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Admin Dashboard - Medical Project</title>
    <link rel="stylesheet" href="admin_dashboard.css" />
    <style>
        /* Basic styling for cards and links */
        .cards {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        .card {
            background-color: #4CAF50;
            color: white;
            padding: 20px;
            border-radius: 8px;
            flex: 1 1 200px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            cursor: pointer;
            transition: background-color 0.3s ease;
            text-align: center;
            text-decoration: none;
        }
        .card:hover {
            background-color: #45a049;
        }
        .card h3 {
            margin: 0 0 10px;
            font-size: 1.2rem;
        }
        .card p {
            font-size: 1.5rem;
            margin: 0;
            font-weight: 700;
        }
    </style>
</head>
<body>

<header>
    <h1>Admin Dashboard</h1>
    <p>Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?>!</p>
    <a href="logout.php" class="btn logout-btn">Logout</a>
</header>

<nav>
    <ul>
        <li><a href="admin_dashboard.php">Dashboard Home</a></li>
        <li><a href="manage_users.php">Manage Users</a></li>
        <li><a href="manage_doctors.php">Manage Doctors</a></li>
        <li><a href="manage_medicine.php">Manage Medicine</a></li>
        <li><a href="view_reports.php">View Reports</a></li>
        <li><a href="manage_serials.php">Manage Serial List</a></li>
    </ul>
</nav>

<main>
    <section class="dashboard-summary">
        <h2>Summary</h2>
        <div class="cards">
            <a href="manage_users.php" class="card" title="Manage Users">
                <h3>Total Users</h3>
                <p><?php echo $user_count; ?></p>
            </a>
            <a href="manage_doctors.php" class="card" title="Manage Doctors">
                <h3>Total Doctors</h3>
                <p><?php echo $doctor_count; ?></p>
            </a>
            <a href="manage_medicine.php" class="card" title="Manage Medicine">
                <h3>Medicine Stock</h3>
                <p><?php echo $medicine_stock; ?> Items</p>
            </a>
            <a href="view_reports.php" class="card" title="Emergency Cases">
                <h3>Emergency Cases</h3>
                <p><?php echo $emergency_count; ?></p>
            </a>
        </div>
    </section>
</main>

<footer>
    <p>&copy; <?php echo date("Y"); ?> Medical Project Admin Panel</p>
</footer>

</body>
</html>
