<?php
include 'db_connect.php';

$doctor_id = isset($_GET['doctor_id']) ? intval($_GET['doctor_id']) : 0;
if ($doctor_id <= 0) {
    die("Invalid doctor ID.");
}

$error = "";
$success = "";

// Check if doctor exists
$stmt = $conn->prepare("SELECT name FROM doctors WHERE id = ?");
$stmt->bind_param("i", $doctor_id);
$stmt->execute();
$res = $stmt->get_result();
$doctor = $res->fetch_assoc();
$stmt->close();

if (!$doctor) {
    die("Doctor not found.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $academic_info = trim($_POST['academic_info']);

    // Handle file upload
    $picture_path = null;
    if (isset($_FILES['picture']) && $_FILES['picture']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['picture']['tmp_name'];
        $fileName = $_FILES['picture']['name'];
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];

        if (in_array($fileExtension, $allowed)) {
            $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
            $uploadDir = 'uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true); // Ensure uploads directory exists
            }
            $destPath = $uploadDir . $newFileName;

            if (!move_uploaded_file($fileTmpPath, $destPath)) {
                $error = "Error uploading the picture.";
            } else {
                $picture_path = $destPath;
            }
        } else {
            $error = "Invalid picture format. Allowed: jpg, jpeg, png, gif, webp, bmp.";
        }
    }

    if (!$error) {
        // Insert or update doctor_info
        $stmt = $conn->prepare("SELECT id FROM doctor_info WHERE doctor_id = ?");
        $stmt->bind_param("i", $doctor_id);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // Update existing
            $stmt->bind_result($info_id);
            $stmt->fetch();
            $stmt->close();

            if ($picture_path) {
                $stmt = $conn->prepare("UPDATE doctor_info SET academic_info = ?, picture = ? WHERE id = ?");
                $stmt->bind_param("ssi", $academic_info, $picture_path, $info_id);
            } else {
                $stmt = $conn->prepare("UPDATE doctor_info SET academic_info = ? WHERE id = ?");
                $stmt->bind_param("si", $academic_info, $info_id);
            }
            if ($stmt->execute()) {
                $success = "Doctor info updated successfully.";
            } else {
                $error = "Failed to update doctor info.";
            }
            $stmt->close();
        } else {
            // Insert new
            $stmt->close();
            $stmt = $conn->prepare("INSERT INTO doctor_info (doctor_id, academic_info, picture) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $doctor_id, $academic_info, $picture_path);
            if ($stmt->execute()) {
                $success = "Doctor info added successfully.";
            } else {
                $error = "Failed to add doctor info.";
            }
            $stmt->close();
        }
    }
}

// Fetch existing doctor_info if any
$stmt = $conn->prepare("SELECT academic_info, picture FROM doctor_info WHERE doctor_id = ?");
$stmt->bind_param("i", $doctor_id);
$stmt->execute();
$res = $stmt->get_result();
$doctor_info = $res->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Add / Edit Doctor Info for Dr. <?= htmlspecialchars($doctor['name']) ?></title>
<style>
    body {
        font-family: Arial, sans-serif;
        padding: 20px;
        max-width: 600px;
        margin: auto;
        background-color: #f9f9f9;
    }
    h1 {
        text-align: center;
        color: #333;
    }
    label {
        display: block;
        margin-top: 15px;
        font-weight: bold;
        color: #333;
    }
    textarea,
    input[type="file"] {
        width: 100%;
        margin-top: 5px;
        padding: 8px;
        font-size: 14px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    button {
        margin-top: 20px;
        padding: 10px 15px;
        background: #007bff;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    button:hover {
        background: #0056b3;
    }
    .error {
        color: red;
        margin-top: 15px;
        text-align: center;
    }
    .success {
        color: green;
        margin-top: 15px;
        text-align: center;
    }
    img {
        margin-top: 15px;
        max-width: 100%;
        border-radius: 6px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }
    a {
        display: inline-block;
        margin-top: 20px;
        text-decoration: none;
        color: #007bff;
    }
</style>
</head>
<body>

<h1>Add / Edit Doctor Info for Dr. <?= htmlspecialchars($doctor['name']) ?></h1>

<?php if ($error): ?>
    <p class="error"><?= htmlspecialchars($error) ?></p>
<?php endif; ?>

<?php if ($success): ?>
    <p class="success"><?= htmlspecialchars($success) ?></p>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
    <label for="academic_info">Academic Qualification:</label>
    <textarea name="academic_info" id="academic_info" rows="5" required><?= htmlspecialchars($doctor_info['academic_info'] ?? '') ?></textarea>

    <label for="picture">Upload New Picture (Optional):</label>
    <input type="file" name="picture" id="picture" accept=".jpg,.jpeg,.png,.gif,.webp,.bmp">

    <?php if (!empty($doctor_info['picture']) && file_exists($doctor_info['picture'])): ?>
        <p>Current Picture:</p>
        <img src="<?= htmlspecialchars($doctor_info['picture']) ?>" alt="Doctor Picture">
    <?php elseif (!empty($doctor_info['picture'])): ?>
        <p><em>Picture not found on server. Check upload directory.</em></p>
    <?php endif; ?>

    <button type="submit">Save Doctor Info</button>
</form>

<a href="doctors_serial.php">← Back to Doctor List</a>

</body>
</html>
