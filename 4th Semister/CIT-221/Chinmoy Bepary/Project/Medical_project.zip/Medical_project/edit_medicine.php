<?php
session_start();
include 'db_connect.php';

// Check admin session
if (!isset($_SESSION['admin_name'])) {
    header("Location: admin_login.php");
    exit();
}

// Validate medicine ID
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0) {
    echo "Invalid medicine ID.";
    exit();
}

// Fetch existing data
$stmt = $conn->prepare("SELECT * FROM medicine WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$medicine = $result->fetch_assoc();
$stmt->close();

if (!$medicine) {
    echo "Medicine not found.";
    exit();
}

$success = "";
$error = "";

// Handle update form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $manufacturer = trim($_POST['manufacturer']);
    $expiry_date = $_POST['expiry_date'];
    $quantity = intval($_POST['quantity']);

    if (empty($name) || empty($manufacturer) || empty($expiry_date) || $quantity < 0) {
        $error = "Please fill out all fields correctly.";
    } else {
        $stmt = $conn->prepare("UPDATE medicine SET name = ?, manufacturer = ?, expiry_date = ?, quantity = ? WHERE id = ?");
        $stmt->bind_param("sssii", $name, $manufacturer, $expiry_date, $quantity, $id);

        if ($stmt->execute()) {
            $success = "Medicine updated successfully.";
        } else {
            $error = "Failed to update medicine.";
        }
        $stmt->close();

        // Refresh data after update
        $stmt = $conn->prepare("SELECT * FROM medicine WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $medicine = $result->fetch_assoc();
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Medicine</title>
    <link rel="stylesheet" href="edit_medicine.css">
</head>
<body>
    <div class="container">
        <h2>Edit Medicine</h2>

        <?php if ($error): ?>
            <p class="error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <?php if ($success): ?>
            <p class="success"><?= htmlspecialchars($success) ?></p>
        <?php endif; ?>

        <form method="post">
            <label>Name:</label>
            <input type="text" name="name" value="<?= htmlspecialchars($medicine['name']) ?>" required>

            <label>Manufacturer:</label>
            <input type="text" name="manufacturer" value="<?= htmlspecialchars($medicine['manufacturer']) ?>" required>

            <label>Expiry Date:</label>
            <input type="date" name="expiry_date" value="<?= htmlspecialchars($medicine['expiry_date']) ?>" required>

            <label>Quantity:</label>
            <input type="number" name="quantity" value="<?= htmlspecialchars($medicine['quantity']) ?>" min="0" required>

            <button type="submit">Update</button>
            <a class="back-link" href="manage_medicine.php">← Back</a>
        </form>
    </div>
</body>
</html>
