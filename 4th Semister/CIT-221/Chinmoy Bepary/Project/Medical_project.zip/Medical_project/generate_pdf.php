<?php
require('fpdf.php');
include 'db_connect.php';  // your DB connection file

class PDF extends FPDF {
    function Header() {
        $this->SetFont('Arial','B',14);
        $this->Cell(0,10,'Serial List Report',0,1,'C');
        $this->Ln(5);
    }
}

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);

// Query to get serial list with doctors
$sql = "SELECT a.admit_date AS date, d.name AS doctor, a.serial_no AS serial, a.patient_name AS patient, a.phone 
        FROM admissions a
        JOIN doctors d ON a.doctor_id = d.id
        ORDER BY a.admit_date DESC, d.name ASC, a.serial_no ASC";

$result = $conn->query($sql);

// Table headers
$pdf->Cell(30,10,'Date',1);
$pdf->Cell(50,10,'Doctor',1);
$pdf->Cell(20,10,'Serial',1);
$pdf->Cell(60,10,'Patient',1);
$pdf->Cell(30,10,'Phone',1);
$pdf->Ln();

// Loop data rows
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell(30,10,$row['date'],1);
        $pdf->Cell(50,10,$row['doctor'],1);
        $pdf->Cell(20,10,'#'.$row['serial'],1);
        $pdf->Cell(60,10,$row['patient'],1);
        $pdf->Ln();
    }
} else {
    $pdf->Cell(0,10,'No data found',1,1,'C');
}

$conn->close();

$pdf->Output('serial_report.pdf', 'I');
?>
