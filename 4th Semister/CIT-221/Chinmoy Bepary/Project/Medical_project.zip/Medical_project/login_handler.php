<?php
$email = trim($_POST['email']);
$password = $_POST['password'];

$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    if (password_verify($password, $row['password'])) {
        $_SESSION['user'] = $row['name'];  // Save user session
        header("Location: index.php");
        exit();
    } else {
        $error_message = "Incorrect password.";
    }
} else {
    $error_message = "No user found with that email.";
}

$stmt->close();
