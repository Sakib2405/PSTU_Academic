<?php
session_start();
include 'db_connect.php';

// Check admin session
if (!isset($_SESSION['admin_name'])) {
    header("Location: admin_login.php");
    exit();
}

$error = "";
$success = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $manufacturer = trim($_POST['manufacturer']);
    $expiry_date = $_POST['expiry_date'];
    $quantity = intval($_POST['quantity']);

    if (empty($name) || empty($manufacturer) || empty($expiry_date) || $quantity < 0) {
        $error = "Please fill out all fields correctly.";
    } else {
        $stmt = $conn->prepare("INSERT INTO medicine (name, manufacturer, expiry_date, quantity) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $name, $manufacturer, $expiry_date, $quantity);

        if ($stmt->execute()) {
            $success = "Medicine added successfully.";
        } else {
            $error = "Failed to add medicine.";
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Medicine</title>
    <link rel="stylesheet" href="add_medicine.css">
</head>
<body>
    <div class="container">
        <h2>Add Medicine</h2>

        <?php if ($error): ?>
            <p class="error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <?php if ($success): ?>
            <p class="success"><?= htmlspecialchars($success) ?></p>
        <?php endif; ?>

        <form method="post">
            <label>Name:</label>
            <input type="text" name="name" required>

            <label>Manufacturer:</label>
            <input type="text" name="manufacturer" required>

            <label>Expiry Date:</label>
            <input type="date" name="expiry_date" required>

            <label>Quantity:</label>
            <input type="number" name="quantity" min="0" required>

            <button type="submit">Add Medicine</button>
            <a class="back-link" href="manage_medicine.php">← Back</a>
        </form>
    </div>
</body>
</html>
