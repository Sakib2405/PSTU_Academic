<?php
include 'db_connect.php';

// Fetch all doctors including id for linking
$result = $conn->query("SELECT id, name, specialization, available_days, available_time, room_no, visit_fee FROM doctors");

if (!$result) {
    die("Query Failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor Serial</title>
    <link rel="stylesheet" href="doctors_serial.css">
    
</head>
<body>
    <h1>Doctor Appointment Schedule</h1>

    <!-- Admit Patient button -->
    <a href="admit_patient.php" class="admit-btn">Admit Patient</a>
    
    <h2>Available Doctors</h2>
    <div class="table-container">
        <table border="1" cellpadding="10" cellspacing="0">
            <thead>
                <tr>
                    <th>Serial No.</th>
                    <th>Doctor Name</th>
                    <th>Specialization</th>
                    <th>Available Days</th>
                    <th>Time Slot</th>
                    <th>Room No.</th>
                    <th>Visit Fee (৳)</th>
                </tr>
            </thead>
            <tbody>
                <?php $serial = 1; ?>
                <?php while ($doctor = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $serial++ ?></td>
                    <td>
                        <a href="doctor_profile.php?id=<?= $doctor['id'] ?>" class="doctor-link">
                            <?= htmlspecialchars($doctor['name']) ?>
                        </a>
                    </td>
                    <td><?= htmlspecialchars($doctor['specialization']) ?></td>
                    <td><?= htmlspecialchars($doctor['available_days']) ?></td>
                    <td><?= htmlspecialchars($doctor['available_time']) ?></td>
                    <td><?= htmlspecialchars($doctor['room_no']) ?></td>
                    <td><?= number_format($doctor['visit_fee'], 2) ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <h2>How to Book an Appointment?</h2>
    <ul>
        <li>You can apply online to admit.</li>
        <li>Visit the hospital reception or call our helpline.</li>
        <li>Provide your details and choose an available doctor.</li>
        <li>Confirm your appointment timing.</li>
        <li>Arrive 15 minutes before your scheduled time.</li>
    </ul>

    <h2>Emergency Consultation</h2>
    <p>If you have a medical emergency, please visit the <a href="emergency.html">Emergency Department</a> immediately.</p>

    <a class="back-link" href="index.php">Back to Home</a>
</body>
</html>

<?php $conn->close(); ?>