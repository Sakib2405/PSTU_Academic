<?php
session_start();

// Unset all admin session variables
unset($_SESSION['admin_id']);
unset($_SESSION['admin_name']);

// Destroy the entire session
session_destroy();

// Redirect to the home page after logout
header("Location: index.php");
exit();
