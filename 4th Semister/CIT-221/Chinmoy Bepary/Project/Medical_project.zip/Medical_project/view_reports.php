<?php
session_start();
include 'db_connect.php';

// Only allow admin access
if (!isset($_SESSION['admin_name'])) {
    header("Location: admin_login.php");
    exit();
}

// Fetch all reports ordered by date descending
$result = $conn->query("SELECT id, title, description, report_date, status FROM reports ORDER BY report_date DESC");

if ($result === false) {
    die("Database error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>View Reports - Admin</title>
<link rel="stylesheet" href="view_reports.css" />
</head>
<body>

<header>
    <h1>Reports Dashboard</h1>
    <a href="admin_dashboard.php" class="btn back-btn">← Back to Dashboard</a>
    <a href="logout.php" class="btn logout-btn">Logout</a>
</header>

<main>
    <?php if ($result->num_rows > 0): ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>Date</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($report = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($report['id']); ?></td>
                <td><?php echo htmlspecialchars($report['title']); ?></td>
                <td><?php echo htmlspecialchars($report['description']); ?></td>
                <td><?php echo htmlspecialchars($report['report_date']); ?></td>
                <td><?php echo htmlspecialchars($report['status']); ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>No reports found.</p>
    <?php endif; ?>
</main>

<footer>
    <p>&copy; <?php echo date("Y"); ?> Medical Project Admin Panel</p>
</footer>

</body>
</html>

<?php
$conn->close();
?>
